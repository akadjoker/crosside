#pragma once

#include <filesystem>
#include <string>
#include <vector>

#include "core/context.hpp"

namespace crosside::io {

struct ProcessResult {
    int code = -1;
    std::string commandLine;
};

std::string shellQuote(const std::string &value);
ProcessResult runCommand(
    const std::string &command,
    const std::vector<std::string> &args,
    const std::filesystem::path &cwd,
    const crosside::Context &ctx,
    bool dryRun = false
);

} // namespace crosside::io
