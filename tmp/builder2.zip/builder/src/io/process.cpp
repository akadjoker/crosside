#include "io/process.hpp"

#include <cstdlib>
#include <filesystem>
#include <sstream>
#include <vector>
#include <string>

#ifdef _WIN32
#include <windows.h>
#include <memory>
#else
#include <unistd.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <cerrno>
#include <cstring>
#endif

namespace crosside::io
{

    namespace
    {

#ifdef _WIN32
        // Windows implementation using CreateProcess
        ProcessResult runCommandWindows(
            const std::string &command,
            const std::vector<std::string> &args,
            const std::filesystem::path &cwd,
            const crosside::Context &ctx)
        {
            ProcessResult result;

            // Build command line
            std::ostringstream cmdLine;
            cmdLine << command;
            for (const auto &arg : args)
            {
                cmdLine << ' ' << arg;
            }
            result.commandLine = cmdLine.str();

            // Convert to wide string for Windows API
            int wideSize = MultiByteToWideChar(CP_UTF8, 0, result.commandLine.c_str(), -1, nullptr, 0);
            if (wideSize == 0)
            {
                result.code = -1;
                ctx.error("Failed to convert command to wide string");
                return result;
            }

            std::vector<wchar_t> wideCmdLine(wideSize);
            MultiByteToWideChar(CP_UTF8, 0, result.commandLine.c_str(), -1, wideCmdLine.data(), wideSize);

            // Convert working directory if provided
            std::vector<wchar_t> wideCwd;
            wchar_t *cwdPtr = nullptr;
            if (!cwd.empty())
            {
                std::string cwdStr = cwd.string();
                int cwdSize = MultiByteToWideChar(CP_UTF8, 0, cwdStr.c_str(), -1, nullptr, 0);
                if (cwdSize > 0)
                {
                    wideCwd.resize(cwdSize);
                    MultiByteToWideChar(CP_UTF8, 0, cwdStr.c_str(), -1, wideCwd.data(), cwdSize);
                    cwdPtr = wideCwd.data();
                }
            }

            // Setup process structures
            STARTUPINFOW si;
            PROCESS_INFORMATION pi;
            ZeroMemory(&si, sizeof(si));
            si.cb = sizeof(si);
            ZeroMemory(&pi, sizeof(pi));

            // Create the process
            BOOL success = CreateProcessW(
                nullptr,            // Application name (null = use command line)
                wideCmdLine.data(), // Command line
                nullptr,            // Process security attributes
                nullptr,            // Thread security attributes
                FALSE,              // Inherit handles
                0,                  // Creation flags
                nullptr,            // Environment
                cwdPtr,             // Current directory
                &si,                // Startup info
                &pi                 // Process info
            );

            if (!success)
            {
                result.code = -1;
                DWORD error = GetLastError();
                ctx.error("Failed to create process: Error code ", error);
                return result;
            }

            // Wait for process to complete
            WaitForSingleObject(pi.hProcess, INFINITE);

            // Get exit code
            DWORD exitCode = 0;
            if (GetExitCodeProcess(pi.hProcess, &exitCode))
            {
                result.code = static_cast<int>(exitCode);
            }
            else
            {
                result.code = -1;
                ctx.error("Failed to get process exit code");
            }

            // Cleanup
            CloseHandle(pi.hProcess);
            CloseHandle(pi.hThread);

            return result;
        }

#else

        // POSIX implementation using fork/exec
        ProcessResult runCommandPosix(
            const std::string &command,
            const std::vector<std::string> &args,
            const std::filesystem::path &cwd,
            const crosside::Context &ctx)
        {
            ProcessResult result;

            // Build command line for display
            std::ostringstream cmdLine;
            cmdLine << command;
            for (const auto &arg : args)
            {
                cmdLine << ' ' << arg;
            }
            result.commandLine = cmdLine.str();

            // Prepare argv array for execvp
            std::vector<char *> argv;
            argv.reserve(args.size() + 2);

            // Need to make mutable copies of strings
            std::vector<std::string> argStorage;
            argStorage.push_back(command);
            for (const auto &arg : args)
            {
                argStorage.push_back(arg);
            }

            for (auto &arg : argStorage)
            {
                argv.push_back(const_cast<char *>(arg.c_str()));
            }
            argv.push_back(nullptr);

            // Fork the process
            pid_t pid = fork();

            if (pid < 0)
            {
                // Fork failed
                result.code = -1;
                ctx.error("Failed to fork process: ", std::strerror(errno));
                return result;
            }

            if (pid == 0)
            {
                // Child process

                // Change directory if requested
                if (!cwd.empty())
                {
                    if (chdir(cwd.c_str()) != 0)
                    {
                        std::cerr << "Failed to change directory: " << std::strerror(errno) << std::endl;
                        _exit(127);
                    }
                }

                // Execute the command
                execvp(command.c_str(), argv.data());

                // If execvp returns, it failed
                std::cerr << "Failed to execute command '" << command << "': "
                          << std::strerror(errno) << std::endl;
                _exit(127);
            }

            // Parent process - wait for child
            int status = 0;
            pid_t waitResult = waitpid(pid, &status, 0);

            if (waitResult < 0)
            {
                result.code = -1;
                ctx.error("Failed to wait for process: ", std::strerror(errno));
                return result;
            }

            if (WIFEXITED(status))
            {
                result.code = WEXITSTATUS(status);
            }
            else if (WIFSIGNALED(status))
            {
                int signal = WTERMSIG(status);
                result.code = 128 + signal;
                ctx.warn("Process terminated by signal: ", signal);
            }
            else
            {
                result.code = -1;
                ctx.error("Process ended abnormally");
            }

            return result;
        }

#endif

    } // anonymous namespace

    // Original shellQuote function - kept for backward compatibility if needed
    std::string shellQuote(const std::string &value)
    {
#ifdef _WIN32
        if (value.empty())
        {
            return "\"\"";
        }

        bool needQuotes = false;
        for (char ch : value)
        {
            if (ch == ' ' || ch == '\t' || ch == '"')
            {
                needQuotes = true;
                break;
            }
        }
        if (!needQuotes)
        {
            return value;
        }

        std::string out;
        out.push_back('"');
        std::size_t backslashes = 0;
        for (char ch : value)
        {
            if (ch == '\\')
            {
                ++backslashes;
                continue;
            }
            if (ch == '"')
            {
                out.append(backslashes * 2 + 1, '\\');
                out.push_back('"');
                backslashes = 0;
                continue;
            }
            out.append(backslashes, '\\');
            backslashes = 0;
            out.push_back(ch);
        }
        out.append(backslashes * 2, '\\');
        out.push_back('"');
        return out;
#else
        std::string out;
        out.reserve(value.size() + 2);
        out.push_back('\'');
        for (char ch : value)
        {
            if (ch == '\'')
            {
                out += "'\\''";
            }
            else
            {
                out.push_back(ch);
            }
        }
        out.push_back('\'');
        return out;
#endif
    }

    ProcessResult runCommand(
        const std::string &command,
        const std::vector<std::string> &args,
        const std::filesystem::path &cwd,
        const crosside::Context &ctx,
        bool dryRun)
    {
        // Build display command line
        std::ostringstream cmd;
        cmd << shellQuote(command);
        for (const auto &arg : args)
        {
            cmd << ' ' << shellQuote(arg);
        }

        ProcessResult result;
        result.commandLine = cmd.str();

        if (!cwd.empty())
        {
            ctx.log("cwd: ", cwd.string());
        }
        ctx.log(result.commandLine);

        if (dryRun)
        {
            result.code = 0;
            return result;
        }

        // Verify working directory exists if provided
        if (!cwd.empty())
        {
            std::error_code ec;
            if (!std::filesystem::exists(cwd, ec) || !std::filesystem::is_directory(cwd, ec))
            {
                result.code = -1;
                ctx.error("Working directory does not exist: ", cwd.string());
                return result;
            }
        }

#ifdef _WIN32
        return runCommandWindows(command, args, cwd, ctx);
#else
        return runCommandPosix(command, args, cwd, ctx);
#endif
    }

} // namespace crosside::io