# builder (C++ edition)

CLI build tool reimplementation of `crosside_cli.py` in modern C++.

## Goals
- Single native binary
- No Qt / no Python runtime needed for CLI
- Modular code by domain/platform

## Build
```bash
cd builder
make debug
# or
make release
```

Binary output:
- `builder/bin/builder`

## Commands
```bash
./bin/builder list all
./bin/builder clean bugame web --dry-run
./bin/builder build module miniz desktop --mode debug
./bin/builder build bugame desktop --skip-modules
./bin/builder serve projects/bugame/Web/main.html --port 8080
```

## Current status
- `list`: implemented
- `clean`: implemented
- `build desktop`: implemented for modules and apps
- `build android`: implemented in C++ (module/app, APK packaging, signing, install/run)
- `build web`: implemented in C++ (module/app, shell template, preload assets, built-in multithread socket server for `--run`)

## Android manifest template
`main.mk` can customize manifest generation in `Android` block:

```json
"Android": {
  "PACKAGE": "com.djokersoft.game",
  "ACTIVITY": "android.app.NativeActivity",
  "LABEL": "Bugame",
  "MANIFEST_TEMPLATE": "android/AndroidManifest.custom.xml",
  "MANIFEST_VARS": {
    "MIN_SDK": "21",
    "TARGET_SDK": "35"
  }
}
```

Supported placeholders:
- Legacy: `@apppkg@`, `@applbl@`, `@appact@`, `@appactv@`, `@appLIBNAME@`
- Extended: `@APP_PACKAGE@`, `@APP_LABEL@`, `@APP_ACTIVITY@`, `@APP_LIB_NAME@`
- Custom vars from `MANIFEST_VARS`: `@KEY@` and `${KEY}`

Default template path:
- `Templates/Android/AndroidManifest.xml`

Platform separation files:
- `src/build/desktop_builder.cpp`
- `src/build/android_builder.cpp`
- `src/build/web_builder.cpp`

Web server implementation:
- `src/io/http_server.cpp`

## JSON library
Using vendored single-header:
- `third_party/nlohmann/json.hpp`
