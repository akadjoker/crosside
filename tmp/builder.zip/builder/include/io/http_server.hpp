#pragma once

#include <filesystem>
#include <string>

#include "core/context.hpp"

namespace crosside::io {

struct StaticHttpServerOptions {
    std::filesystem::path root;
    std::string host = "127.0.0.1";
    int port = 8080;
    std::string indexFile = "index.html";
};

bool serveStaticHttp(const crosside::Context &ctx, const StaticHttpServerOptions &options);

} // namespace crosside::io
