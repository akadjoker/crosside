#include "io/http_server.hpp"

#include <array>
#include <cctype>
#include <cstdint>
#include <condition_variable>
#include <cstring>
#include <fstream>
#include <mutex>
#include <queue>
#include <string>
#include <string_view>
#include <thread>
#include <unordered_map>

#ifdef _WIN32
#define NOMINMAX
#include <winsock2.h>
#include <ws2tcpip.h>
#else
#include <arpa/inet.h>
#include <cerrno>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>
#endif

namespace fs = std::filesystem;

namespace crosside::io {
namespace {

#ifdef _WIN32
using SocketHandle = SOCKET;
constexpr SocketHandle kInvalidSocket = INVALID_SOCKET;
#else
using SocketHandle = int;
constexpr SocketHandle kInvalidSocket = -1;
#endif

void closeSocket(SocketHandle handle) {
    if (handle == kInvalidSocket) {
        return;
    }
#ifdef _WIN32
    closesocket(handle);
#else
    close(handle);
#endif
}

std::string socketErrorText() {
#ifdef _WIN32
    return std::to_string(WSAGetLastError());
#else
    return std::strerror(errno);
#endif
}

bool sendAll(SocketHandle sock, const char *data, std::size_t size) {
    std::size_t sent = 0;
    while (sent < size) {
        const int n = send(
            sock,
            data + sent,
            static_cast<int>(size - sent),
            0
        );
        if (n <= 0) {
            return false;
        }
        sent += static_cast<std::size_t>(n);
    }
    return true;
}

std::string toLower(std::string value) {
    for (char &ch : value) {
        ch = static_cast<char>(std::tolower(static_cast<unsigned char>(ch)));
    }
    return value;
}

int hexValue(char c) {
    if (c >= '0' && c <= '9') {
        return c - '0';
    }
    c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    if (c >= 'a' && c <= 'f') {
        return 10 + (c - 'a');
    }
    return -1;
}

std::string urlDecode(const std::string &raw) {
    std::string out;
    out.reserve(raw.size());

    for (std::size_t i = 0; i < raw.size(); ++i) {
        const char ch = raw[i];
        if (ch == '%' && i + 2 < raw.size()) {
            const int hi = hexValue(raw[i + 1]);
            const int lo = hexValue(raw[i + 2]);
            if (hi >= 0 && lo >= 0) {
                out.push_back(static_cast<char>((hi << 4) | lo));
                i += 2;
                continue;
            }
        }
        if (ch == '+') {
            out.push_back(' ');
            continue;
        }
        out.push_back(ch);
    }
    return out;
}

std::string detectMimeType(const fs::path &path) {
    static const std::unordered_map<std::string, std::string> kTable = {
        {".html", "text/html; charset=utf-8"},
        {".htm", "text/html; charset=utf-8"},
        {".js", "application/javascript; charset=utf-8"},
        {".mjs", "application/javascript; charset=utf-8"},
        {".css", "text/css; charset=utf-8"},
        {".json", "application/json; charset=utf-8"},
        {".txt", "text/plain; charset=utf-8"},
        {".xml", "application/xml; charset=utf-8"},
        {".wasm", "application/wasm"},
        {".data", "application/octet-stream"},
        {".bin", "application/octet-stream"},
        {".png", "image/png"},
        {".jpg", "image/jpeg"},
        {".jpeg", "image/jpeg"},
        {".gif", "image/gif"},
        {".webp", "image/webp"},
        {".svg", "image/svg+xml"},
        {".ico", "image/x-icon"},
        {".wav", "audio/wav"},
        {".ogg", "audio/ogg"},
        {".mp3", "audio/mpeg"},
        {".mp4", "video/mp4"},
    };

    const std::string ext = toLower(path.extension().string());
    auto it = kTable.find(ext);
    if (it != kTable.end()) {
        return it->second;
    }
    return "application/octet-stream";
}

std::string statusText(int code) {
    switch (code) {
        case 200:
            return "OK";
        case 400:
            return "Bad Request";
        case 403:
            return "Forbidden";
        case 404:
            return "Not Found";
        case 405:
            return "Method Not Allowed";
        case 500:
            return "Internal Server Error";
        default:
            return "Error";
    }
}

bool sendSimpleResponse(
    SocketHandle sock,
    int statusCode,
    const std::string &body,
    const std::string &contentType,
    bool headOnly
) {
    std::string header = "HTTP/1.1 " + std::to_string(statusCode) + " " + statusText(statusCode) + "\r\n";
    header += "Content-Type: " + contentType + "\r\n";
    header += "Content-Length: " + std::to_string(body.size()) + "\r\n";
    header += "Connection: close\r\n";
    if (statusCode == 405) {
        header += "Allow: GET, HEAD\r\n";
    }
    header += "\r\n";

    if (!sendAll(sock, header.data(), header.size())) {
        return false;
    }
    if (!headOnly && !body.empty()) {
        return sendAll(sock, body.data(), body.size());
    }
    return true;
}

bool parseRequestLine(
    const std::string &requestHeader,
    std::string &methodOut,
    std::string &targetOut
) {
    const std::size_t firstEnd = requestHeader.find("\r\n");
    if (firstEnd == std::string::npos) {
        return false;
    }

    const std::string firstLine = requestHeader.substr(0, firstEnd);
    const std::size_t p1 = firstLine.find(' ');
    if (p1 == std::string::npos) {
        return false;
    }
    const std::size_t p2 = firstLine.find(' ', p1 + 1);
    if (p2 == std::string::npos) {
        return false;
    }

    methodOut = firstLine.substr(0, p1);
    targetOut = firstLine.substr(p1 + 1, p2 - (p1 + 1));
    return !methodOut.empty() && !targetOut.empty();
}

bool sanitizeRequestPath(
    const std::string &rawTarget,
    const std::string &indexFile,
    fs::path &relativeOut
) {
    std::string target = rawTarget;
    const std::size_t q = target.find('?');
    if (q != std::string::npos) {
        target = target.substr(0, q);
    }
    const std::size_t h = target.find('#');
    if (h != std::string::npos) {
        target = target.substr(0, h);
    }

    if (target.empty()) {
        target = "/";
    }

    std::string decoded = urlDecode(target);
    for (char &ch : decoded) {
        if (ch == '\\') {
            ch = '/';
        }
    }

    if (!decoded.empty() && decoded.front() == '/') {
        decoded.erase(decoded.begin());
    }

    fs::path rel;
    std::size_t begin = 0;
    while (begin <= decoded.size()) {
        std::size_t end = decoded.find('/', begin);
        if (end == std::string::npos) {
            end = decoded.size();
        }

        const std::string token = decoded.substr(begin, end - begin);
        begin = end + 1;

        if (token.empty() || token == ".") {
            if (end == decoded.size()) {
                break;
            }
            continue;
        }
        if (token == "..") {
            return false;
        }

        rel /= token;
        if (end == decoded.size()) {
            break;
        }
    }

    if (rel.empty()) {
        rel = indexFile;
    }

    relativeOut = rel;
    return true;
}

bool sendFileResponse(SocketHandle sock, const fs::path &filePath, bool headOnly) {
    std::ifstream in(filePath, std::ios::binary);
    if (!in.is_open()) {
        return sendSimpleResponse(sock, 404, "Not found\n", "text/plain; charset=utf-8", headOnly);
    }

    std::error_code ec;
    const std::uintmax_t size = fs::file_size(filePath, ec);
    if (ec) {
        return sendSimpleResponse(sock, 500, "Failed to read file size\n", "text/plain; charset=utf-8", headOnly);
    }

    std::string header = "HTTP/1.1 200 OK\r\n";
    header += "Content-Type: " + detectMimeType(filePath) + "\r\n";
    header += "Content-Length: " + std::to_string(size) + "\r\n";
    header += "Connection: close\r\n";
    header += "Cache-Control: no-cache\r\n";
    header += "\r\n";

    if (!sendAll(sock, header.data(), header.size())) {
        return false;
    }
    if (headOnly) {
        return true;
    }

    std::array<char, 16 * 1024> chunk{};
    while (in.good()) {
        in.read(chunk.data(), static_cast<std::streamsize>(chunk.size()));
        const std::streamsize got = in.gcount();
        if (got <= 0) {
            break;
        }
        if (!sendAll(sock, chunk.data(), static_cast<std::size_t>(got))) {
            return false;
        }
    }
    return true;
}

bool handleClient(
    SocketHandle client,
    const fs::path &serveRoot,
    const std::string &indexFile
) {
    std::string request;
    request.reserve(4096);

    std::array<char, 4096> buffer{};
    for (;;) {
        const int got = recv(client, buffer.data(), static_cast<int>(buffer.size()), 0);
        if (got <= 0) {
            return false;
        }
        request.append(buffer.data(), static_cast<std::size_t>(got));
        if (request.find("\r\n\r\n") != std::string::npos) {
            break;
        }
        if (request.size() > 64 * 1024) {
            return sendSimpleResponse(client, 400, "Header too large\n", "text/plain; charset=utf-8", false);
        }
    }

    std::string method;
    std::string target;
    if (!parseRequestLine(request, method, target)) {
        return sendSimpleResponse(client, 400, "Bad request\n", "text/plain; charset=utf-8", false);
    }

    const bool headOnly = method == "HEAD";
    if (!(method == "GET" || headOnly)) {
        return sendSimpleResponse(client, 405, "Only GET/HEAD supported\n", "text/plain; charset=utf-8", headOnly);
    }

    fs::path rel;
    if (!sanitizeRequestPath(target, indexFile, rel)) {
        return sendSimpleResponse(client, 403, "Forbidden\n", "text/plain; charset=utf-8", headOnly);
    }

    fs::path filePath = serveRoot / rel;
    std::error_code ec;
    if (fs::is_directory(filePath, ec)) {
        filePath /= indexFile;
    }

    if (!fs::exists(filePath, ec) || !fs::is_regular_file(filePath, ec)) {
        return sendSimpleResponse(client, 404, "Not found\n", "text/plain; charset=utf-8", headOnly);
    }

    return sendFileResponse(client, filePath, headOnly);
}

class SocketRuntime {
public:
    explicit SocketRuntime(const crosside::Context &ctx) : ok_(true) {
#ifdef _WIN32
        WSADATA data{};
        if (WSAStartup(MAKEWORD(2, 2), &data) != 0) {
            ok_ = false;
            ctx.error("WSAStartup failed");
        }
#else
        (void)ctx;
#endif
    }

    ~SocketRuntime() {
#ifdef _WIN32
        if (ok_) {
            WSACleanup();
        }
#endif
    }

    bool ok() const { return ok_; }

private:
    bool ok_ = false;
};

std::size_t computeWorkerCount() {
    unsigned int cpu = std::thread::hardware_concurrency();
    if (cpu == 0) {
        return 4;
    }
    if (cpu < 2) {
        return 2;
    }
    if (cpu > 8) {
        return 8;
    }
    return static_cast<std::size_t>(cpu);
}

class ClientWorkerPool {
public:
    ClientWorkerPool(std::size_t workerCount, fs::path root, std::string indexFile)
        : root_(std::move(root)), indexFile_(std::move(indexFile)) {
        workers_.reserve(workerCount);
        for (std::size_t i = 0; i < workerCount; ++i) {
            workers_.emplace_back([this]() { workerLoop(); });
        }
    }

    ~ClientWorkerPool() {
        shutdown();
    }

    void enqueue(SocketHandle client) {
        std::lock_guard<std::mutex> lock(mutex_);
        if (stopping_) {
            closeSocket(client);
            return;
        }
        queue_.push(client);
        cv_.notify_one();
    }

    void shutdown() {
        {
            std::lock_guard<std::mutex> lock(mutex_);
            if (stopping_) {
                return;
            }
            stopping_ = true;
            while (!queue_.empty()) {
                closeSocket(queue_.front());
                queue_.pop();
            }
        }

        cv_.notify_all();
        for (auto &worker : workers_) {
            if (worker.joinable()) {
                worker.join();
            }
        }
        workers_.clear();
    }

private:
    void workerLoop() {
        for (;;) {
            SocketHandle client = kInvalidSocket;
            {
                std::unique_lock<std::mutex> lock(mutex_);
                cv_.wait(lock, [this]() { return stopping_ || !queue_.empty(); });
                if (stopping_ && queue_.empty()) {
                    return;
                }
                client = queue_.front();
                queue_.pop();
            }

            if (client != kInvalidSocket) {
                (void)handleClient(client, root_, indexFile_);
                closeSocket(client);
            }
        }
    }

    fs::path root_;
    std::string indexFile_;
    std::mutex mutex_;
    std::condition_variable cv_;
    std::queue<SocketHandle> queue_;
    std::vector<std::thread> workers_;
    bool stopping_ = false;
};

} // namespace

bool serveStaticHttp(const crosside::Context &ctx, const StaticHttpServerOptions &options) {
    if (options.port <= 0 || options.port > 65535) {
        ctx.error("Invalid HTTP server port: ", options.port);
        return false;
    }

    std::error_code ec;
    const fs::path root = fs::absolute(options.root, ec);
    if (ec || !fs::exists(root, ec) || !fs::is_directory(root, ec)) {
        ctx.error("Invalid HTTP server root: ", options.root.string());
        return false;
    }

    SocketRuntime runtime(ctx);
    if (!runtime.ok()) {
        return false;
    }

    SocketHandle server = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (server == kInvalidSocket) {
        ctx.error("Failed create socket: ", socketErrorText());
        return false;
    }

    int reuse = 1;
#ifdef _WIN32
    setsockopt(server, SOL_SOCKET, SO_REUSEADDR, reinterpret_cast<const char *>(&reuse), sizeof(reuse));
#else
    setsockopt(server, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(reuse));
#endif

    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(static_cast<unsigned short>(options.port));

    const std::string host = options.host.empty() ? "127.0.0.1" : options.host;
    if (inet_pton(AF_INET, host.c_str(), &addr.sin_addr) != 1) {
        ctx.error("Invalid HTTP server host: ", host);
        closeSocket(server);
        return false;
    }

    if (bind(server, reinterpret_cast<sockaddr *>(&addr), sizeof(addr)) != 0) {
        ctx.error("Failed bind ", host, ":", options.port, " : ", socketErrorText());
        closeSocket(server);
        return false;
    }

    if (listen(server, 16) != 0) {
        ctx.error("Failed listen on ", host, ":", options.port, " : ", socketErrorText());
        closeSocket(server);
        return false;
    }

    const std::string indexFile = options.indexFile.empty() ? std::string("index.html") : options.indexFile;
    const std::size_t workerCount = computeWorkerCount();
    ClientWorkerPool workers(workerCount, root, indexFile);

    ctx.log("HTTP server listening on http://", host, ":", options.port, "/");
    ctx.log("Serve root: ", root.string());
    ctx.log("Worker threads: ", workerCount);
    ctx.log("Press Ctrl+C to stop.");

    for (;;) {
        sockaddr_in clientAddr{};
#ifdef _WIN32
        int addrLen = sizeof(clientAddr);
#else
        socklen_t addrLen = sizeof(clientAddr);
#endif
        SocketHandle client = accept(server, reinterpret_cast<sockaddr *>(&clientAddr), &addrLen);
        if (client == kInvalidSocket) {
            ctx.warn("Accept failed: ", socketErrorText());
            continue;
        }

        workers.enqueue(client);
    }

    closeSocket(server);
    return true;
}

} // namespace crosside::io
