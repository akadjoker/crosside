#include "io/process.hpp"

#include <cstdlib>
#include <filesystem>
#include <sstream>

#ifndef _WIN32
#include <sys/wait.h>
#endif

namespace crosside::io {

std::string shellQuote(const std::string &value) {
#ifdef _WIN32
    if (value.empty()) {
        return "\"\"";
    }

    bool needQuotes = false;
    for (char ch : value) {
        if (ch == ' ' || ch == '\t' || ch == '"') {
            needQuotes = true;
            break;
        }
    }
    if (!needQuotes) {
        return value;
    }

    std::string out;
    out.push_back('"');
    std::size_t backslashes = 0;
    for (char ch : value) {
        if (ch == '\\') {
            ++backslashes;
            continue;
        }
        if (ch == '"') {
            out.append(backslashes * 2 + 1, '\\');
            out.push_back('"');
            backslashes = 0;
            continue;
        }
        out.append(backslashes, '\\');
        backslashes = 0;
        out.push_back(ch);
    }
    out.append(backslashes * 2, '\\');
    out.push_back('"');
    return out;
#else
    std::string out;
    out.reserve(value.size() + 2);
    out.push_back('\'');
    for (char ch : value) {
        if (ch == '\'') {
            out += "'\\''";
        } else {
            out.push_back(ch);
        }
    }
    out.push_back('\'');
    return out;
#endif
}

ProcessResult runCommand(
    const std::string &command,
    const std::vector<std::string> &args,
    const std::filesystem::path &cwd,
    const crosside::Context &ctx,
    bool dryRun
) {
    std::ostringstream cmd;
    cmd << shellQuote(command);
    for (const auto &arg : args) {
        cmd << ' ' << shellQuote(arg);
    }

    ProcessResult result;
    result.commandLine = cmd.str();

    if (!cwd.empty()) {
        ctx.log("cwd: ", cwd.string());
    }
    ctx.log(result.commandLine);
    if (dryRun) {
        result.code = 0;
        return result;
    }

    std::error_code ec;
    const std::filesystem::path previousCwd = std::filesystem::current_path(ec);
    if (ec) {
        result.code = -1;
        ctx.error("Failed to read current directory: ", ec.message());
        return result;
    }

    if (!cwd.empty()) {
        std::filesystem::current_path(cwd, ec);
        if (ec) {
            result.code = -1;
            ctx.error("Failed to change directory to ", cwd.string(), " : ", ec.message());
            return result;
        }
    }

    int code = std::system(result.commandLine.c_str());
    std::filesystem::current_path(previousCwd, ec);
    if (ec) {
        ctx.warn("Failed to restore directory: ", ec.message());
    }

    if (code == -1) {
        result.code = -1;
#ifdef _WIN32
    } else {
        result.code = code;
#else
    } else if (WIFEXITED(code)) {
        result.code = WEXITSTATUS(code);
    } else {
        result.code = code;
    }
#endif
    return result;
}

} // namespace crosside::io
