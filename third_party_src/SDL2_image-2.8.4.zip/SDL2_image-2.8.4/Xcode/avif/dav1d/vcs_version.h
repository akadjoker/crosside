/* auto-generated, do not edit */
#define DAV1D_VERSION "1.2.1-3-g5315741"
