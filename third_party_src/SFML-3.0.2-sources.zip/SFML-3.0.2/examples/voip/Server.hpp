#pragma once

void doServer(unsigned short port);
