#pragma once

void doClient(unsigned short port);
